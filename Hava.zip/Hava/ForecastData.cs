﻿using System;
namespace Hava
{
    public class ForecastData
    {
       
    }
}
}
