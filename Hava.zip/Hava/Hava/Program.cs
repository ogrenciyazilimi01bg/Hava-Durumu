﻿using System;
using System.Net.Http;
using System.Threading.Tasks;
using Hava;
using Newtonsoft.Json;

class Program
{
    public static async Task Main()
    {
        string ProgramaGirisTarihi = ("Tarih :" + DateTime.Now);
        Console.WriteLine("                               * Canım Ülkem Hava Durumu *           " + ProgramaGirisTarihi);//Hava Durumu ismi ve programa giriş tarihi.
        Console.WriteLine("Aşağıda 3 büyük ilimizin bugün ve 3 gün sonrasınına kadar olan hava durumu yer almaktadır.");
        WeatherData istanbulWeather = await GetWeatherData("https://goweather.herokuapp.com/weather/istanbul");
        WeatherData izmirWeather = await GetWeatherData("https://goweather.herokuapp.com/weather/izmir");
        WeatherData ankaraWeather = await GetWeatherData("https://goweather.herokuapp.com/weather/ankara");

        Console.WriteLine("....................................................................................................");
        Console.WriteLine("İstanbul Hava Durumu:");
        PrintWeather(istanbulWeather);
        Console.WriteLine("....................................................................................................");
        Console.WriteLine("\nİzmir Hava Durumu:");
        PrintWeather(izmirWeather);
        Console.WriteLine("....................................................................................................");
        Console.WriteLine("\nAnkara Hava Durumu:");
        PrintWeather(ankaraWeather);
        Console.WriteLine("************************************************");
        Console.WriteLine("* Hava nasıl olursa olsun,enerjiniz bol olsun. *");
        Console.WriteLine("************************************************");
        Console.WriteLine("\n");
    }
    //Apiden veri alma
    public static async Task<WeatherData> GetWeatherData(string apiUrl)
    {
        using (HttpClient client = new HttpClient())
        {
            HttpResponseMessage response = await client.GetAsync(apiUrl);

            if (response.IsSuccessStatusCode)
            {
                string responseData = await response.Content.ReadAsStringAsync();
                WeatherData weatherData = JsonConvert.DeserializeObject<WeatherData>(responseData);
                return weatherData;
            }
            else
            {
                Console.WriteLine($"API'den veri alınamıyor.Lütfen daha sonra tekrar deneyin. Durum Kodu: {response.StatusCode}");
                return null;
            }
        }
    }
    //Hava durumu bilgilerini yazdırma.
    public static void PrintWeather(WeatherData weather)
    {
        if (weather != null)
        {
            Console.WriteLine("\n");
            Console.WriteLine(DateTime.Now.ToShortDateString() +" "+ DateTime.Now.ToString("dddd"));
            Console.WriteLine($"Sıcaklık: {weather.Temperature}");
            Console.WriteLine($"Rüzgar: {weather.Wind}");
            Console.WriteLine($"Durum: {weather.Description}");
            Console.WriteLine("\n");
            Console.WriteLine("Tahmini Hava Durumu:");//Tahmini hava durumu

            // Gerçek tarih
            DateTime gercekTarih = DateTime.Now;

            foreach (var forecast in weather.Forecast)
            {
                // Gerçek tarihi bir gün artır
                gercekTarih = gercekTarih.AddDays(1);

                // Tahmini hava durumu bilgileri
                Console.WriteLine($" {forecast.Day} Gün sonra: {gercekTarih.ToString(" dd MMMM dddd ")} : {forecast.Temperature}  {forecast.Description}  Rüzgar: {forecast.Wind}");
            }

            Console.WriteLine("\n");
        }
    }
}
